import React from "react";
import Warper from "./Warper";
import Popup from "reactjs-popup";
//

const contentStyle = {
  maxWidth: "600px",
  width: "90%"
};

const Card = ({ title }) => (
  <div className="card">
    <div className="header">{title}</div>
    <div className="content">
      자고싶다ssafavavsvasfasfas
    </div>
  </div>
);


const CustomModal = ({title}) => (
  <Popup
    trigger={<button className="position_button"> QB </button>}
    modal
    contentStyle={contentStyle}
  >
    {close => (
      <div className="modal">
        <div className="header"> 쿼터백(Quarter Back) {title} </div>
        <div className="content">
          {" "}
          나랏말싸미 듕궉에 달아
          <br />
          시발 {' '}
          <Popup
            trigger={<a><font color="FF00CC">이거</font></a>}
            position="bottom center"
            on="hover"
          >
          <Card title="졸려" />
          </Popup>
          {' '}언제다하냐?
        </div>
        <div className="actions">
          <button
            className="button"
            onClick={() => {
              console.log("modal closed ");
              close();
            }}
          >
            close
          </button>
        </div>
      </div>
    )}
  </Popup>
);

export default Warper(CustomModal);
